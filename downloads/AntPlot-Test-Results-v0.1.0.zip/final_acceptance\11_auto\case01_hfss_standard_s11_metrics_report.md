# Engineering Metrics Report

```text
Messages:
WARNING:
- [port_reference_unconfirmed] 端口参考面未确认；默认不判断 50 ohm、renormalization 或 de-embed 状态。
INFO:
- [info] 频率范围高于 1 GHz，建议按需求使用 GHz 或 MHz，并保持坐标轴单位一致。
- [info] 未指定目标频段，未进行带宽合格性判断。
- [info] S11/VSWR/Smith/阻抗相关结果需要确认端口参考阻抗、参考面、renormalization 与 de-embed 设置。
- [interpolation] S11 threshold crossings use linear interpolation between adjacent raw samples.
- [export_vector_recommended] 建议导出 PDF/SVG 用于论文排版和矢量编辑。
- [realized_gain_recommended] 建议优先使用 Realized Gain 反映端口失配后的实际工作性能。

File: C:\Users\26246\Documents\Codex\2026-06-21\lei\examples\s11_cases\case01_hfss_standard.csv
Rows: 3
Detected kind: s11
Frequency column: Freq [GHz]
Frequency range: 1600 to 1800 MHz (GHz)
Columns:
  - Freq [GHz] (numeric used)
  - dB(S(1,1)) [] (numeric used)
Variables used or detected:
  - dB(S(1,1)) []
Warnings:
  - 端口参考面未确认；默认不判断 50 ohm、renormalization 或 de-embed 状态。
Notes:
  - 频率范围高于 1 GHz，建议按需求使用 GHz 或 MHz，并保持坐标轴单位一致。
  - 未指定目标频段，未进行带宽合格性判断。
  - S11/VSWR/Smith/阻抗相关结果需要确认端口参考阻抗、参考面、renormalization 与 de-embed 设置。

Project settings:
- Port impedance: 50 ohm
- Prefer Realized Gain: True
- Working band: not specified; no pass/fail bandwidth judgment was made.

Engineering metrics:
- Curve: S(1,1) [S11]
  data_covers_target_band: None
  max_s11_in_target_band_db: not available
  satisfies_s11_threshold_in_target_band: not judged
  lowest_resonance_frequency_mhz: 1700.0
  lowest_s11_db: -15.0
  minus_10db_band_mhz: 1628.57-1783.33
  minus_10db_bandwidth_mhz: 154.7619047619046
  minus_10db_center_mhz: 1705.952380952381
  minus_10db_fractional_bandwidth_percent: 9.071877180739698
  all_target_band_s11_le_threshold: not judged
  interpolation:
    - S11 threshold crossings use linear interpolation between adjacent raw samples.
```
